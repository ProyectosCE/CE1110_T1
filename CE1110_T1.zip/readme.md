# Instituto Tecnológico de Costa Rica

## Tarea 1

### FFT y Sistemas de Modulación

#### Análisis de Señales Mixtas (CE1110)

---

### Estudiantes

* José Bernardo Barquero Bonilla (2023150476)
* Jimmy Feng Feng (2023060347)
* Alexander Montero Vargas (2023166058)

### Profesor

* Luis Alberto Chavarría Zamora — *[lachavarria@itcr.ac.cr](mailto:lachavarria@itcr.ac.cr)*

---
